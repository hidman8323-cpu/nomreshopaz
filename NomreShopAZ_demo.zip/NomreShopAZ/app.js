const countries = [
 {name:"Azərbaycan",dial:"+994",flag:"🇦🇿",price:"—"},
 {name:"Türkiyə",dial:"+90",flag:"🇹🇷",price:"7.00 ₼"},
 {name:"ABŞ",dial:"+1",flag:"🇺🇸",price:"7.00 ₼"},
 {name:"Böyük Britaniya",dial:"+44",flag:"🇬🇧",price:"7.00 ₼"},
 {name:"Almaniya",dial:"+49",flag:"🇩🇪",price:"7.00 ₼"},
 {name:"Fransa",dial:"+33",flag:"🇫🇷",price:"7.00 ₼"},
 {name:"Niderland",dial:"+31",flag:"🇳🇱",price:"11.00 ₼"},
 {name:"Kanada",dial:"+1",flag:"🇨🇦",price:"7.00 ₼"},
 {name:"İndoneziya",dial:"+62",flag:"🇮🇩",price:"7.00 ₼"},
 {name:"Filippin",dial:"+63",flag:"🇵🇭",price:"7.00 ₼"},
 {name:"Mərakeş",dial:"+212",flag:"🇲🇦",price:"7.00 ₼"},
 {name:"Kolumbiya",dial:"+57",flag:"🇨🇴",price:"7.00 ₼"},
 {name:"Cənubi Afrika",dial:"+27",flag:"🇿🇦",price:"7.00 ₼"},
 {name:"Çili",dial:"+56",flag:"🇨🇱",price:"7.00 ₼"},
 {name:"Kamerun",dial:"+237",flag:"🇨🇲",price:"7.00 ₼"},
 {name:"Vyetnam",dial:"+84",flag:"🇻🇳",price:"7.00 ₼"},
 {name:"Anqola",dial:"+244",flag:"🇦🇴",price:"7.00 ₼"},
 {name:"Özbəkistan",dial:"+998",flag:"🇺🇿",price:"7.00 ₼"},
 {name:"Madaqaskar",dial:"+261",flag:"🇲🇬",price:"8.50 ₼"},
 {name:"Monqolustan",dial:"+976",flag:"🇲🇳",price:"8.80 ₼"},
 {name:"Argentina",dial:"+54",flag:"🇦🇷",price:"11.00 ₼"}
];
const grid = document.getElementById("country-grid");
const search = document.getElementById("search");
const empty = document.getElementById("empty");
function render(){
 const q = search.value.trim().toLocaleLowerCase("az");
 const filtered = countries.filter(c => (c.name+" "+c.dial).toLocaleLowerCase("az").includes(q));
 grid.innerHTML = filtered.map(c => `<article class="country"><span class="flag">${c.flag}</span><div><div class="country-name">${c.name}</div><div class="dial">${c.dial}</div></div><span class="price">${c.price}</span></article>`).join("");
 empty.hidden = filtered.length !== 0;
}
search.addEventListener("input",render);
document.getElementById("year").textContent = new Date().getFullYear();
render();