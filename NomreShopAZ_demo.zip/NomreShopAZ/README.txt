NOMRESHOPAZ — DEMO SAYT

Fayllar:
- index.html: saytın səhifəsi
- style.css: görünüş və mobil uyğunlaşma
- app.js: ölkələr, nümunə qiymətlər və axtarış

Yoxlama:
1. ZIP-i açın.
2. index.html faylını brauzerdə açın.

Vacib:
Bu, işlək dizayn prototipidir; canlı nömrə/SMS satışı etmir.
Canlı sistem üçün:
1. Nömrə/SMS provayderindən rəsmi reseller API və API sənədləri alın.
2. API açarlarını yalnız serverdə saxlayan backend qurun (HTML/JS-ə yazmayın).
3. Ödəniş provayderi ilə merchant hesabı açın və webhook vasitəsilə ödənişi təsdiqləyin.
4. Məxfilik siyasəti, istifadə şərtləri, geri ödəniş qaydası və dəstək əlaqəsi əlavə edin.
5. Hostingə yerləşdirib domen və HTTPS qoşun.
6. Test sifarişləri ilə yoxlayın.

QEYD: destek@nomreshopaz.example nümunə ünvandır; öz real dəstək ünvanınızla əvəz edin.
Qiymətlər nümunədir və provayderin real qiymətləri/komissiyaları əsasında yenilənməlidir.
